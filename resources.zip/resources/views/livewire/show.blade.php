    <div>
        <style>
            .shows{
                position: fixed;
                left: 0;
                top: 0;
                width: 100%;
                height: 100vh;
                background-color: #95A0AF;
                opacity: 0.5;
                z-index:1;
            }
        </style>
        <div class="shows"></div>
    </div>
