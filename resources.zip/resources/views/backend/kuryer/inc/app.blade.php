@include('backend.kuryer.inc.header')
@yield('content')
@include('backend.kuryer.inc.footer')