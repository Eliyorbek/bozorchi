@extends('backend.kuryer.inc.app')
@section('content')
    @livewire('kuryer.yetkazilgan.yetkazilganlar-component')
@endsection