@extends('backend.kuryer.inc.app')
@section('content')
            @livewire('kuryer.dashboard-component')
@endsection