@extends('backend.inc.app')
@section('content')

    @livewire('profil.my-profil-component')
@endsection