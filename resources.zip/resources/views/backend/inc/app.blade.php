@include('backend.inc.header')
@yield('content')
@include('backend.inc.footer')